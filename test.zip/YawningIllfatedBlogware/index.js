const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const path = require('path');

// 将根路径返回 select.html 内容
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'select.html'));
});
// 模拟的分组数据，每个组的总名额、当前剩余、已选次数以及上次分配时间
let groups = [
  {
    name: "group1",
    url: "https://farm.pcibex.net/r/IXWmsM/",
    total: 3,
    remaining: 3,
    selectedCount: 0,
    lastSelected: null
  },
  {
    name: "group2",
    url: "https://farm.pcibex.net/r/ZQNKoR/",
    total: 3,
    remaining: 3,
    selectedCount: 0,
    lastSelected: null
  }
];

// 解析 JSON 格式数据（如请求体中的 JSON）
app.use(express.json());

// 提供静态文件目录（前端 HTML、JS、CSS 等）
app.use(express.static('public'));

/**
 * GET /api/stats
 * 返回所有组的统计信息，供管理员页面查看
 */
app.get('/api/stats', (req, res) => {
  res.json({ groups });
});

/**
 * POST /api/select
 * 随机选择一个还有剩余名额的组，扣除对应名额，并返回该组的实验链接
 */
app.post('/api/select', (req, res) => {
  // 筛选出有剩余名额的组
  const availableGroups = groups.filter(group => group.remaining > 0);

  if (availableGroups.length === 0) {
    return res.status(400).json({ error: "No slots remaining." });
  }

  // 从剩余组随机选取一个
  const randomIndex = Math.floor(Math.random() * availableGroups.length);
  const selectedGroup = availableGroups[randomIndex];

  // 扣除一个名额，并更新统计数据
  selectedGroup.remaining--;
  selectedGroup.selectedCount++;
  selectedGroup.lastSelected = new Date().toISOString();

  res.json({ group: selectedGroup.name, url: selectedGroup.url });
});

// 启动服务器
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});